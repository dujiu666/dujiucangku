public interface Wodefa {
    public abstract  void kehuguli();
    public abstract  void show();
}
